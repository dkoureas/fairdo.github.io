var JEKYLL_PAGES_API_SEARCH_INDEX_URL = '/search-index.json';
